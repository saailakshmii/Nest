export interface Cat {
  name: string;
  age: number;
  breed: string;
}
