export class CreateExternalSvcDto {}
