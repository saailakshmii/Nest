export class CreateDogDto {}
