export declare class AppController {
  root(): string;
}
